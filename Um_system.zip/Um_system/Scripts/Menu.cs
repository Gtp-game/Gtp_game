using Godot;
using System;
using System.IO.Ports;

public class Menu : Control
{
	public int dates = 2;
	private SerialPort _serialPort;

	public override void _Ready()
	{
		// Настройки последовательного порта
		string portName = "COM5"; // Замените на нужный порт
		int baudRate = 115200; // Скорость передачи данных
		_serialPort = new SerialPort(portName, baudRate);

		try
		{
			_serialPort.Open();
			GD.Print("Порт открыт.");
		}
		catch (Exception e)
		{
			GD.PrintErr("Ошибка при открытии порта: " + e.Message);
		}
	}

	public void SendData(string data)
	{
		if (_serialPort.IsOpen)
		{
			try
			{
				// Отправка данных
				_serialPort.WriteLine(data);
				GD.Print("Данные отправлены: " + data);
			}
			catch (Exception e)
			{
				GD.PrintErr("Ошибка при отправке данных: " + e.Message);
			}
		}
		else
		{
			GD.PrintErr("Порт не открыт. Невозможно отправить данные.");
		}
	}

	public override void _Process(float delta)
	{
		// Пример отправки данных каждую секунду
		// Вы можете изменить логику по вашему усмотрению
		if (OS.GetTicksMsec() % 1000 < delta * 750)
		{
			if (dates == 1)
			{
			SendData("1");
			dates = 0;
			}
			//else
			//{
			//SendData("0");
			//dates = 1;
			//}
		}
	}

	public override void _ExitTree()
	{
		if (_serialPort != null && _serialPort.IsOpen)
		{
			_serialPort.Close();
			GD.Print("Порт закрыт.");
		}
	}
}
